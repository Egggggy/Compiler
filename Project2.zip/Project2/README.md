組員:     
資工三 廖酉詳 108590024(coding)   
資工三 張君瑋 108590035(debugg)   

此為溫度調節器功能的語法    

指令:

    $ flex Project2.l
    $ bison -d Project2.y       
    $ gcc lex.yy.c Project2.tab.c       
