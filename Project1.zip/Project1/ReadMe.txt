組員(一名)
廖酉詳 資工三 108590024

Target Language : C語言
execution environments : Ubuntu